## Data Visualization for Policy Analysis
## Pulling Maps from the Google API w/ ggmap

# install.packages("ggmap")

library(dplyr)
library(ggplot2)
library(ggmap)

map <- get_map(location = 'Europe', zoom = 4)
ggmap(map)


## You can specify various sources and map types:
act_map <- get_map(c(149.1, -35.325), zoom = 11, source = "google", maptype = "roadmap")
ggmap(act_map)

## get_map takes c(longitude, latitude)
ist_map <- get_map(c(28.979530, 41.01513), zoom = 12, source = "google", maptype = "terrain")
ggmap(ist_map)


## And we can use the Google API to geocode locations:
dc_loc <- geocode("Washington, D.C.")
dc_loc

dc_map <- qmap(c(lon=dc_loc$lon, lat=dc_loc$lat), source="google", zoom=12)
dc_map


## School Level Data, colored by charter = 1|0
schools <- read.csv("slims_mapping.csv")
glimpse(schools)

dc_map + 
	geom_point(data=schools, aes(x=MAR_LONGITUDE, y=MAR_LATITUDE))

# add na.rm
dc_map + 
	geom_point(data=schools, aes(x=MAR_LONGITUDE, y=MAR_LATITUDE), na.rm=TRUE)

## Color by DCPS or Public School:
dc_map + 
  geom_point(data=schools, aes(x=MAR_LONGITUDE, y=MAR_LATITUDE, colour=Charter))



## Add names layer, remove legend to give more space:
dc_map + 
	geom_point(data=schools, aes(x=MAR_LONGITUDE, y=MAR_LATITUDE, colour=Charter), size=3) + 
	geom_text(data = schools, aes(x=MAR_LONGITUDE, y=MAR_LATITUDE, label = School_Name), size = 1, vjust = 0, hjust = -0.2) +
	theme(legend.position="none")

