## Simple loop to generate columns of latitude and longitude from addresses.
library(ggmap)

# First, create two empty columns for latitude and longitude in your dataframe:
df$lat <- NA
df$lon <- NA

# Now,in a for loop, iterate through all the rows of the dataframe.
for(i in 1:nrow(df)){
	# Take the column with the address and pass it into the geocode()function from the ggmal library. Save the output as x.
	x <- geocode(df$address[i])

	# Save the generated latitude and longitude into the appropriate columns you made a minute ago.
	map$lon[i] <- x[1]
	map$lat[i] <- x[2]
}


