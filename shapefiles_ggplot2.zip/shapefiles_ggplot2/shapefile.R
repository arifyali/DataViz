## Data Visualization for Policy Analysis
## Using Shapesfiles in R

## Can be adapted to any shapefile, like those for most global administrative areas, found here: http://gadm.org/country
## Guide Adapted from here: https://github.com/hadley/ggplot2/wiki/plotting-polygon-shapefiles

## You need a lot of specialized packages for this:
install.packages("gpclib") ## may need to hit /n after installing
install.packages("rgeos")
install.packages("rgdal")
install.packages("maptools")
install.packages("ggplot2")

library(gpclib)
library(rgeos)
library(rgdal)
library(maptools)
library(ggplot2)

## Read in wards demographic data:
wards <- read.csv("wards.csv")
wards


## Read in the shapefile with readOGR. Use arguments:
# dsn = "folder_name"
# layer = "shapefile_name"
ward_map <- readOGR(dsn="WardPly", layer="WardPly")

## Look at the loaded shapefile:
class(ward_map) # It is a spatial dataframe, which not ideal to work with.
ward_map@data
ward_map@data$WARD_ID
ward_map@data$AREASQMI


## We use 'fortify' to transition from a spatial data to a normal dataframe:
ward.points <- fortify(ward_map, region="WARD_ID")
head(ward.points, n=20)

## Merge on the wards demographic data (this is a normal merge):
ward.df = merge(ward.points, wards, by.x="id", by.y="Ward")
head(ward.df, n=20)


ggplot(data=ward.df, aes(long, lat, group=group, fill=AfAmpovpercent)) + 
  geom_polygon()

ggplot(data=ward.df, aes(long, lat, group=group, fill=AfAmpovpercent)) + 
  geom_polygon() +
  geom_path(color="white") + 
  coord_equal()

ggplot(data=ward.df, aes(long, lat, group=group, fill=AfAmpovpercent)) + 
  geom_polygon() +
  geom_path(color="white") + 
  coord_equal() + 
  scale_fill_distiller(palette = "Spectral")


## More examples: http://www.unomaha.edu/mahbubulmajumder/data-science/fall-2014/lectures/06-display-spatial-data/06-display-spatial-data.html#/

## If you want to remove all the chart junk, you can use this theme:
theme_clean_map <- function(base_size = 12) {
    require(grid)
    theme_grey(base_size) %+replace%
    theme(
        axis.title      =   element_blank(),
        axis.text       =   element_blank(),
        axis.ticks       =   element_blank(),
        panel.background    =   element_blank(),
        panel.grid      =   element_blank(),
        panel.margin    =   unit(0,"lines"),
        plot.margin     =   unit(c(0,0,0,0),"lines"),
        complete = TRUE
        )
    }

ggplot(data=ward.df, aes(long, lat, group=group, fill=AfAmpovpercent)) + 
  geom_polygon() +
  geom_path(color="white") + 
  coord_equal() + 
  theme_clean_map() 
